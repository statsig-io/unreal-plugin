#pragma once
//
// #include "../../initialize_request_args.h"
//
// namespace statsig::data_types::initialize_request_args {
//
// std::string Serialize(const internal::InitializeRequestArgs &args) {
//   return "";
// }
//
// }