#pragma once

#include "../../error_boundary.hpp"

namespace statsig::data_types::error_boundary_request_args {

std::string Serialize(const internal::ErrorBoundaryRequestArgs &args) {
  return "";
}

}